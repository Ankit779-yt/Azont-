import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import BookList from './components/BookList';
import BookForm from './components/BookForm';
import { Book } from './types';
import { PlusCircle, Search } from 'lucide-react';

// Mock data for demonstration
const initialBooks: Book[] = [
  {
    id: '1',
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    genre: 'Classic',
    isbn: '978-0743273565',
    description: 'A story of decadence and excess.',
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=200&h=300',
    tags: ['classic', 'fiction'],
    downloads: 1500,
    views: 3000,
    createdAt: '2024-03-10',
  },
  // Add more mock books as needed
];

function App() {
  const [books, setBooks] = useState<Book[]>(initialBooks);
  const [searchQuery, setSearchQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [selectedBook, setSelectedBook] = useState<Book | undefined>();

  const filteredBooks = books.filter((book) =>
    Object.values(book).some((value) =>
      String(value).toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  const handleAddBook = (newBook: Partial<Book>) => {
    const book: Book = {
      ...newBook,
      id: Date.now().toString(),
      downloads: 0,
      views: 0,
      createdAt: new Date().toISOString(),
    } as Book;
    
    setBooks([...books, book]);
    setShowForm(false);
  };

  const handleEditBook = (updatedBook: Partial<Book>) => {
    setBooks(
      books.map((book) =>
        book.id === selectedBook?.id ? { ...book, ...updatedBook } : book
      )
    );
    setShowForm(false);
    setSelectedBook(undefined);
  };

  const handleDeleteBook = (id: string) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      setBooks(books.filter((book) => book.id !== id));
    }
  };

  return (
    <Router>
      <Layout>
        <Routes>
          <Route
            path="/"
            element={
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h1 className="text-2xl font-bold text-gray-900">Books</h1>
                  <button
                    onClick={() => setShowForm(true)}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
                  >
                    <PlusCircle className="h-5 w-5 mr-2" />
                    Add Book
                  </button>
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search books..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  />
                </div>

                <BookList
                  books={filteredBooks}
                  onEdit={(book) => {
                    setSelectedBook(book);
                    setShowForm(true);
                  }}
                  onDelete={handleDeleteBook}
                  onView={(book) => {
                    // Implement view functionality
                    console.log('Viewing book:', book);
                  }}
                />

                {showForm && (
                  <BookForm
                    book={selectedBook}
                    onSubmit={selectedBook ? handleEditBook : handleAddBook}
                    onClose={() => {
                      setShowForm(false);
                      setSelectedBook(undefined);
                    }}
                  />
                )}
              </div>
            }
          />
          {/* Add more routes for Analytics, Categories, and Users */}
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;