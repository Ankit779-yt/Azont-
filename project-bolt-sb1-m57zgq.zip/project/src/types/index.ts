export interface Book {
  id: string;
  title: string;
  author: string;
  genre: string;
  isbn: string;
  description: string;
  coverUrl: string;
  tags: string[];
  downloads: number;
  views: number;
  createdAt: string;
}

export interface User {
  id: string;
  email: string;
  role: 'admin' | 'editor' | 'viewer';
}

export type SortDirection = 'asc' | 'desc';
export type SortField = 'title' | 'author' | 'views' | 'downloads' | 'createdAt';